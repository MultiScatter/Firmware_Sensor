/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "AS3933.h"
#include "hdc2080.h"
#include "opt3002.h"
#include "aux_func.h"
#include "HM.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define MSGSIZE 38 // backscatter packet size
#define PKT_LEN MSGSIZE-14 // 14 bytes preamble, sync word
#define LINE_LENGTH 162 //number of pixels in one line of image
#define TIMER_VALUE 3000 // timeout timer value

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
 ADC_HandleTypeDef hadc;

CRC_HandleTypeDef hcrc;

I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;

LPTIM_HandleTypeDef hlptim1;

SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi2;
DMA_HandleTypeDef hdma_spi1_rx;
DMA_HandleTypeDef hdma_spi1_tx;
DMA_HandleTypeDef hdma_spi2_tx;
DMA_HandleTypeDef hdma_spi2_rx;

/* USER CODE BEGIN PV */

const uint8_t WAKEUUP_PATTERN_1st_BYTE = 0x65;  //tag4(0x45): 0100 -> 01100101
const uint8_t WAKEUUP_PATTERN_2nd_BYTE = 0x9a; //tag4(0x45): 0101 -> 01100110

uint8_t SPI_RxBuffer[LINE_LENGTH]; // camera buffer
uint8_t SPI_TxBuffer[LINE_LENGTH]; // backscatter SPI buffer
uint8_t line_received = 0; // flag for receiving an image line
uint8_t radio_interrupt;
uint8_t sensor_interrupt;
uint8_t image_interrupt;
uint8_t pkt_complete; // backscatter flag
uint8_t end_frame = 1; // end frame flag
uint8_t charge; // battery voltage
uint8_t counter_line = 0; // camera line counter
uint8_t image[122][120]; // image data buffer
uint8_t temp_humidity[4];
uint16_t illum;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI2_Init(void);
static void MX_I2C2_Init(void);
static void MX_CRC_Init(void);
static void MX_LPTIM1_Init(void);
static void MX_ADC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();
  MX_I2C1_Init();
  MX_SPI2_Init();
  MX_I2C2_Init();
  MX_CRC_Init();
  MX_LPTIM1_Init();
  MX_ADC_Init();
  /* USER CODE BEGIN 2 */
  //Make sure DMA init function is called before SPI and USART init functions!!!!!!
  /* After each code genetation do:
   * 1- stm32l0xx_hal_spi.c set hspi->hdmatx->XferHalfCpltCallback to NULL (line 1733 in current version) to prevent half-transmit wake up interrupt
   * 2- stm32l0xx_hal_spi.c comment out "Check the end of the transaction" operation in SPI_DMAReceiveCplt() function (line 2829-2832 in current driver file)
   * 3- stm32l0xx_hal_spi.c comment out "Check the end of the transaction" operation in SPI_DMATransmitReceiveCplt() function (line 2905-2908 in current driver file)
   */


  HAL_Delay(10);
  HAL_GPIO_WritePin(MEAS_EN_GPIO_Port, MEAS_EN_Pin, GPIO_PIN_SET); // enable voltage reader
  HAL_ADC_Start(&hadc);
  init_as3933(); // wake-up radio init
  hdc2080_init(); // humidity and temp sensors init in manual trig mode


  uint8_t transmitBuffer[MSGSIZE] = {0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x90, 0x4e, 0x18, 0x1a}; // preamble, sync word, ...
  uint8_t* data = &transmitBuffer[12]; // data buffer

  uint16_t row,col;

  row = 0;
  col = 0;

  HAL_GPIO_WritePin(LEDR_GPIO_Port, LEDR_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(TX_RATE_GPIO_Port, TX_RATE_Pin, GPIO_PIN_SET); // turn on Q1A to bypass R17
  HAL_GPIO_WritePin(TX_PWR_GPIO_Port, TX_PWR_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(TX_EN_GPIO_Port, TX_EN_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(TX_RX_GPIO_Port, TX_RX_Pin, GPIO_PIN_SET); // RX mode

  HAL_SuspendTick();


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  uint8_t tag_cmd; //command from basestation
  charge = 0;
  radio_interrupt = 0;
  sensor_interrupt = 0;
  image_interrupt = 0;
  hdc2080_triggerMeasurement(); // trigger temp and humidity sensor
  while ((ADC1->ISR & ADC_ISR_EOC) == 0) /* wait end of conversion make sure ADC is ready to read battery voltage */
  {

  }
  opt3002_continous(); // trigger illum sensor measurement
  charge = (uint8_t)HAL_ADC_GetValue(&hadc); // read battery voltage
  HAL_ADC_Stop(&hadc);
  HAL_GPIO_WritePin(MEAS_EN_GPIO_Port, MEAS_EN_Pin, GPIO_PIN_RESET); // disable battery measurement circuitry

    /*Disable MCO clock output.*/
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_NOCLOCK, RCC_MCODIV_4);


  while (1)
  {
	  // enable interrupts before going to stop mode
	  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
	  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);


	  HAL_NVIC_SetPriority(EXTI2_3_IRQn, 0, 0);
	  HAL_NVIC_EnableIRQ(EXTI2_3_IRQn);

	  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
	  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

	  HAL_PWR_EnterSTOPMode(PWR_LOWPOWERREGULATOR_ON, PWR_SLEEPENTRY_WFI);
//	  HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);


	  // disable interrupts
	  HAL_NVIC_DisableIRQ(EXTI0_1_IRQn);
	  HAL_NVIC_DisableIRQ(EXTI2_3_IRQn);
	  HAL_NVIC_DisableIRQ(EXTI4_15_IRQn);

	  if(radio_interrupt == 1) // wake up interrupt from  radio
	  {

		  tag_cmd = as3933_wakeCallback();

		  // enable the high frequency crystal
		  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
		  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
		  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
		  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
		  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
		  {
			  Error_Handler();
		  }
		  __HAL_RCC_SYSCLK_CONFIG(RCC_SYSCLKSOURCE_HSE);

		  HAL_GPIO_WritePin(TX_RX_GPIO_Port, TX_RX_Pin, GPIO_PIN_RESET); // switch to tx mode
		  HAL_GPIO_WritePin(TX_PWR_GPIO_Port, TX_PWR_Pin, GPIO_PIN_SET); //enable oscillator
		  HAL_GPIO_WritePin(TX_EN_GPIO_Port, TX_EN_Pin, GPIO_PIN_SET);


		  if (tag_cmd == 0x08) // read env. data, battery voltage, and image_captured flag
		  {
			  data[2] = tag_cmd; // resend command for confirmation
			  (*(uint16_t*)(&data[0]))++;
			  data[3] = temp_humidity[0];
			  data[4] = temp_humidity[1];
			  data[5] = temp_humidity[2];
			  data[6] = temp_humidity[3];
			  data[7] = (uint8_t)(illum>>8);
			  data[8] = (uint8_t)(illum);
			  data[9] = 0;
			  data[10] = 0;
			  data [11] = charge;
			  pkt_complete = 1;
			  hdc2080_triggerMeasurement(); // trigger the next measurement
			  HAL_GPIO_WritePin(MEAS_EN_GPIO_Port, MEAS_EN_Pin, GPIO_PIN_SET);
			  HAL_ADC_Start(&hadc);

			  uplink_repeat(transmitBuffer, MSGSIZE, data, PKT_LEN, 3);

		  }


		  //send image portion
		  else if ((tag_cmd & 0xF0) == 0x10)
		  {
			  row = ((tag_cmd - 0x10)<<3) + ((tag_cmd - 0x10)<<1) ; //*10 find the requested image portion based on cmd
			  col = 0;
			  uint8_t pkts;
			  uint8_t i;
			  pkt_complete = 1;
			  for (pkts = 0; pkts < 60; pkts++)
			  {
				  data[0] = row;
				  data[1] = col;
				  data[2] = tag_cmd;
				  for (i=3;i<23;i++)
				  {
					  data[i] = image[row][col++];
				  }
				  uplink(transmitBuffer, MSGSIZE, data, PKT_LEN);
				  if(col >= 120)
				  {
					  col = 0;
					  row += 1;
					  if(row >= 120)
					  {

						  row = 0;


					  }
				  }

			  }

		  }
		  else if (tag_cmd == 0x03) //take picture command
		  {

			  data[0] = 0;
			  data[1] = 0;
			  data[2] = tag_cmd;
			  pkt_complete = 1;
			  image_interrupt = 1; //set the flag
			  uplink_repeat(transmitBuffer, MSGSIZE, data, PKT_LEN,3); //ack to basestation

		  }

		  else if ((tag_cmd & 0x80) == 0x80) // send a portion of 12 portions of image
		  {
			  uint16_t row_portion = (tag_cmd)&(0x7F); //find the start row
			  uint16_t col_portion = 0;
			  uint8_t pkts;
			  uint8_t i;
			  pkt_complete = 1;

			  //prepare data
			  for (pkts = 0; pkts < 6; pkts++)
			  {
				  data[0] = row_portion;
				  data[1] = col_portion;
				  data[2] = tag_cmd;
				  for (i=3;i<23;i++)
				  {
					  data[i] = image[row_portion][col_portion++];
				  }
				  uplink(transmitBuffer, MSGSIZE, data, PKT_LEN);
			  }
		  }

		  //default
		  else
		  {
			  data[2] = tag_cmd;
			  (*(uint16_t*)(&data[0]))++;
			  data[3] = 0x00;
			  data[4] = 0x00;
			  data[5] = 0x00;
			  data[6] = 0x00;
			  data[7] = 0x00;
			  data[8] = 0x00;
			  pkt_complete = 1;
			  uplink_repeat(transmitBuffer, MSGSIZE, data, PKT_LEN,3);
		  }

		  //switch to rx mode
		  HAL_GPIO_WritePin(TX_EN_GPIO_Port, TX_EN_Pin, GPIO_PIN_RESET);
		  HAL_GPIO_WritePin(TX_PWR_GPIO_Port, TX_PWR_Pin, GPIO_PIN_RESET);
		  HAL_GPIO_WritePin(TX_RX_GPIO_Port, TX_RX_Pin, GPIO_PIN_SET);

		  // disable the flag
		  radio_interrupt = 0;



	  }
	  // temp and humidity data ready interrupt
	  if(sensor_interrupt == 1)
	  {
		  sensor_interrupt = 0;
		  hdc2080_readSensors(temp_humidity);
		  opt3002_read((uint8_t*)&illum);


		  charge = (uint8_t)HAL_ADC_GetValue(&hadc);
		  HAL_ADC_Stop(&hadc);
		  HAL_GPIO_WritePin(MEAS_EN_GPIO_Port, MEAS_EN_Pin, GPIO_PIN_RESET);

	  }

	  // image record function
	  if (image_interrupt == 1)
	  {
		  image_interrupt = 0;
		  HAL_GPIO_WritePin(EN2V8_GPIO_Port, EN2V8_Pin, GPIO_PIN_SET); // enable image sensor
		  end_frame = 1; // set end flag
		  pkt_complete = 1;

		  // turn on PLL to generate 3 MHz clock for the sensor
		  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
		  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
		  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
		  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLLMUL_3;
		  RCC_OscInitStruct.PLL.PLLDIV = RCC_PLLDIV_4;
		  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
		  {
			Error_Handler();
		  }
		  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLLCLK, RCC_MCODIV_1);
		  hm01b0_init(&hi2c1); //image sensor init
		  hm01b0_stream(&hi2c1, 1); // record one frame
		  HAL_SPI_Receive_DMA(&hspi1, SPI_RxBuffer, LINE_LENGTH); // MCU in SPI slave mode to receive image data line by line
		  counter_line = 0;
		  line_received = 0;
		  uint8_t i;
		  HAL_LPTIM_Counter_Start_IT(&hlptim1, TIMER_VALUE); // set a timeout for the sensor

		  //read and save image data line by line
		  while(end_frame)
		  {
			  if (line_received == 1)
			  {
				  line_received = 0;
				  for(i=0; i<120;i++)
				  {
					  image[counter_line][i] = SPI_RxBuffer [21 + i];
				  }
				  counter_line++;
				  if(counter_line == 122)
				  {
					  counter_line = 0;
					  HAL_LPTIM_Counter_Stop_IT(&hlptim1);
					  end_frame = 0;
					  break;
				  }
				  HAL_SPI_Receive_DMA(&hspi1, SPI_RxBuffer, LINE_LENGTH);
			  }

		  }
		  // disable sensor and PLL
		  HAL_GPIO_WritePin(EN2V8_GPIO_Port, EN2V8_Pin, GPIO_PIN_RESET);
		  RCC->CR &= (uint32_t)(~RCC_CR_PLLON);
		  while((RCC->CR & RCC_CR_PLLRDY) != 0)
		  {

		  }
		  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_NOCLOCK, RCC_MCODIV_4);


	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSE;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_LPTIM1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  PeriphClkInit.LptimClockSelection = RCC_LPTIM1CLKSOURCE_LSI;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_RCC_MCOConfig(RCC_MCO1, RCC_MCO1SOURCE_PLLCLK, RCC_MCODIV_1);
}

/**
  * @brief ADC Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC_Init(void)
{

  /* USER CODE BEGIN ADC_Init 0 */

  /* USER CODE END ADC_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC_Init 1 */

  /* USER CODE END ADC_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc.Instance = ADC1;
  hadc.Init.OversamplingMode = DISABLE;
  hadc.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc.Init.Resolution = ADC_RESOLUTION_8B;
  hadc.Init.SamplingTime = ADC_SAMPLETIME_12CYCLES_5;
  hadc.Init.ScanConvMode = ADC_SCAN_DIRECTION_FORWARD;
  hadc.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc.Init.ContinuousConvMode = DISABLE;
  hadc.Init.DiscontinuousConvMode = DISABLE;
  hadc.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc.Init.DMAContinuousRequests = DISABLE;
  hadc.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc.Init.LowPowerAutoWait = ENABLE;
  hadc.Init.LowPowerFrequencyMode = ENABLE;
  hadc.Init.LowPowerAutoPowerOff = ENABLE;
  if (HAL_ADC_Init(&hadc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel to be converted.
  */
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = ADC_RANK_CHANNEL_NUMBER;
  if (HAL_ADC_ConfigChannel(&hadc, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC_Init 2 */

  /* USER CODE END ADC_Init 2 */

}

/**
  * @brief CRC Initialization Function
  * @param None
  * @retval None
  */
static void MX_CRC_Init(void)
{

  /* USER CODE BEGIN CRC_Init 0 */

  /* USER CODE END CRC_Init 0 */

  /* USER CODE BEGIN CRC_Init 1 */

  /* USER CODE END CRC_Init 1 */
  hcrc.Instance = CRC;
  hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_ENABLE;
  hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_ENABLE;
  hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
  hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
  hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CRC_Init 2 */
  HAL_CRC_DeInit(&hcrc);
  hcrc.Instance = CRC;
  hcrc.Init.DefaultPolynomialUse = DEFAULT_POLYNOMIAL_DISABLE;
  hcrc.Init.DefaultInitValueUse = DEFAULT_INIT_VALUE_DISABLE;
  hcrc.Init.GeneratingPolynomial = 4129;
  hcrc.Init.CRCLength = CRC_POLYLENGTH_16B;
  hcrc.Init.InitValue = 0;
  hcrc.Init.InputDataInversionMode = CRC_INPUTDATA_INVERSION_NONE;
  hcrc.Init.OutputDataInversionMode = CRC_OUTPUTDATA_INVERSION_DISABLE;
  hcrc.InputDataFormat = CRC_INPUTDATA_FORMAT_BYTES;
  if (HAL_CRC_Init(&hcrc) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE END CRC_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x00000E14;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x00000E14;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief LPTIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPTIM1_Init(void)
{

  /* USER CODE BEGIN LPTIM1_Init 0 */

  /* USER CODE END LPTIM1_Init 0 */

  /* USER CODE BEGIN LPTIM1_Init 1 */

  /* USER CODE END LPTIM1_Init 1 */
  hlptim1.Instance = LPTIM1;
  hlptim1.Init.Clock.Source = LPTIM_CLOCKSOURCE_APBCLOCK_LPOSC;
  hlptim1.Init.Clock.Prescaler = LPTIM_PRESCALER_DIV64;
  hlptim1.Init.Trigger.Source = LPTIM_TRIGSOURCE_SOFTWARE;
  hlptim1.Init.OutputPolarity = LPTIM_OUTPUTPOLARITY_HIGH;
  hlptim1.Init.UpdateMode = LPTIM_UPDATE_IMMEDIATE;
  hlptim1.Init.CounterSource = LPTIM_COUNTERSOURCE_INTERNAL;
  if (HAL_LPTIM_Init(&hlptim1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LPTIM1_Init 2 */

  /* USER CODE END LPTIM1_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_SLAVE;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 7;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 7;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel2_3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_3_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_3_IRQn);
  /* DMA1_Channel4_5_6_7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel4_5_6_7_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel4_5_6_7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LEDR_GPIO_Port, LEDR_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, EN2V8_Pin|TX_RX_Pin|TX_PWR_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, RX_CS_Pin|TX_RATE_Pin|TX_EN_Pin|MEAS_EN_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LEDR_Pin */
  GPIO_InitStruct.Pin = LEDR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LEDR_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : EN2V8_Pin TX_RX_Pin TX_PWR_Pin */
  GPIO_InitStruct.Pin = EN2V8_Pin|TX_RX_Pin|TX_PWR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : FVLD_Pin */
  GPIO_InitStruct.Pin = FVLD_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(FVLD_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SEN_TH_Pin */
  GPIO_InitStruct.Pin = SEN_TH_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(SEN_TH_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SEN_AMB_Pin */
  GPIO_InitStruct.Pin = SEN_AMB_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(SEN_AMB_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : RX_CS_Pin TX_RATE_Pin TX_EN_Pin MEAS_EN_Pin */
  GPIO_InitStruct.Pin = RX_CS_Pin|TX_RATE_Pin|TX_EN_Pin|MEAS_EN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PA8 */
  GPIO_InitStruct.Pin = GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF0_MCO;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : RX_CL_DT_Pin RX_DATA_Pin */
  GPIO_InitStruct.Pin = RX_CL_DT_Pin|RX_DATA_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : RX_WAKE_Pin */
  GPIO_InitStruct.Pin = RX_WAKE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(RX_WAKE_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI0_1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI0_1_IRQn);

  HAL_NVIC_SetPriority(EXTI4_15_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI4_15_IRQn);

}

/* USER CODE BEGIN 4 */

void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi1) // image sensor line received callback
{
	line_received = 1;

}

void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi2) //backscatter cmplt callback
{
	pkt_complete = 1;
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if (GPIO_Pin == RX_WAKE_Pin) // wake up radio interrupt
	{
		radio_interrupt = 1;
	}

	else if (GPIO_Pin == SEN_TH_Pin) //sensor data ready interrupt
	{
		sensor_interrupt = 1;
	}


}

void HAL_LPTIM_AutoReloadMatchCallback(LPTIM_HandleTypeDef *hlptim) //timeout interrupt
{


	end_frame = 0;
	HAL_LPTIM_Counter_Stop_IT(&hlptim1);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
