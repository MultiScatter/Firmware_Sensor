/*
 * opt3002.c
 *
 *  Created on: Jan 24, 2020
 *      Author: katanbaf
 */

#include "opt3002.h"

extern I2C_HandleTypeDef hi2c2;

#define hi2c (&hi2c2)
#define DEVICE_ADDR (0x44 << 1)
#define TIMEOUT 5

//Define Register Map
#define RESULT		0x00
#define CONFIG		0x01
#define LOW_LIMIT	0x02
#define HIGH_LIMIT	0x03
#define MAN_ID		0x7e

//Define config Values
#define RANGE_NUM		0x0c

#define CONV_TIME_100		0
#define CONV_TIME_800		1

#define MODE_SHUTDOWN		0
#define MODE_SINGLE			1
#define MODE_CONTINOUS		2

#define LATCH_FIELD_LOW		0
#define LATCH_FIELD_HIGH	1

#define POL_FIELD_LOW		0
#define POL_FIELD_HIGH		1

#define MASK_FIELD_LOW		0
#define MASK_FIELD_HIGH		1

#define FAULT_ONE			0
#define FAULT_TWO			1
#define FAULT_FOUR			2
#define FAULT_EIGHT			3

#define CONFIG_VALUE 		((RANGE_NUM<<12) | (CONV_TIME_100<<11) | (MODE_SINGLE<<9) | (LATCH_FIELD_LOW<<4) | (POL_FIELD_LOW<<3) | (MASK_FIELD_LOW<<2) | (FAULT_TWO))
#define CONFIG_VALUE2 		((RANGE_NUM<<12) | (CONV_TIME_800<<11) | (MODE_CONTINOUS<<9) | (LATCH_FIELD_LOW<<4) | (POL_FIELD_LOW<<3) | (MASK_FIELD_LOW<<2) | (FAULT_TWO))

uint16_t opt3002_readReg()
{
	uint8_t reading[2]; 					// holds byte of read data
	HAL_I2C_Master_Receive(hi2c, DEVICE_ADDR, reading, 2, TIMEOUT);
	return (reading[0] << 8) | reading[1];
}

void opt3002_writeReg(uint8_t reg, uint16_t data)
{
	uint8_t cmd[3];
	cmd[0] = reg;
	cmd[1] = (uint8_t)(data >> 8);
	cmd[2] = (uint8_t)(data);
	HAL_I2C_Master_Transmit(hi2c, DEVICE_ADDR, &cmd[0], 3, TIMEOUT);
}

uint16_t opt3002_readManufacturerID()
{
	uint8_t reg = MAN_ID;
	HAL_I2C_Master_Transmit(hi2c, DEVICE_ADDR, &reg, 1, TIMEOUT);
	return opt3002_readReg();
}


uint16_t opt3002_readResultOnce()
{
	uint16_t value = CONFIG_VALUE;
	opt3002_writeReg(CONFIG, value);

	value = opt3002_readReg();

	while (1)
	{
		value = opt3002_readReg();
		if ((value & 0x0080) != 0)
			break;
	}

	uint8_t reg = RESULT;
	HAL_I2C_Master_Transmit(hi2c, DEVICE_ADDR, &reg, 1, TIMEOUT);
	value =  opt3002_readReg();

	return value;
}

void opt3002_continous()
{
	uint16_t value = CONFIG_VALUE2;
	opt3002_writeReg(CONFIG, value);
}

void opt3002_read(uint8_t* data)
{
	uint8_t reg = RESULT;
	HAL_I2C_Master_Transmit(hi2c, DEVICE_ADDR, &reg, 1, TIMEOUT);
	HAL_I2C_Master_Receive(hi2c, DEVICE_ADDR, data, 2, TIMEOUT);

}
