/*
 * hdc2080.c
 *
 *  Created on: Jan 24, 2020
 *      Author: katanbaf
 */


#include "hdc2080.h"

extern I2C_HandleTypeDef hi2c2;

#define hi2c (&hi2c2)
#define DEVICE_ADDR (0x40 << 1)
#define TIMEOUT 5

void hdc2080_init()
{
	hdc2080_reset();
	hdc2080_setRate(MANUAL);
	hdc2080_setTempRes(FOURTEEN_BIT);
	hdc2080_setHumidRes(FOURTEEN_BIT);
	hdc2080_setMeasurementMode(TEMP_AND_HUMID);
	hdc2080_disableThresholdInterrupt();
	hdc2080_enableDRDYInterrupt();
	hdc2080_setInterruptMode(LEVEL_MODE);
	hdc2080_setInterruptPolarity(ACTIVE_HIGH);
	hdc2080_enableInterrupt();
}

void hdc2080_readSensors(uint8_t* data)
{
	uint8_t reg = TEMP_LOW;
	HAL_I2C_Master_Transmit(hi2c, DEVICE_ADDR, &reg, 1, TIMEOUT);
	HAL_I2C_Master_Receive(hi2c, DEVICE_ADDR, data, 4, TIMEOUT);
}

uint8_t hdc2080_readReg(uint8_t reg)
{
	uint8_t reading; 					// holds byte of read data
	HAL_I2C_Master_Transmit(hi2c, DEVICE_ADDR, &reg, 1, TIMEOUT);
	HAL_I2C_Master_Receive(hi2c, DEVICE_ADDR, &reading, 1, TIMEOUT);
	return reading;
}

void hdc2080_writeReg(uint8_t reg, uint8_t data)
{
	uint8_t cmd[2];
	cmd[0] = reg;
	cmd[1] = data;
	HAL_I2C_Master_Transmit(hi2c, DEVICE_ADDR, cmd, 2, TIMEOUT);
}

uint16_t hdc2080_readRegs(uint8_t low_reg)
{
	uint16_t value = 0x00;
	value = hdc2080_readReg(low_reg+1);
	value = (value << 8) | (hdc2080_readReg(low_reg));
	return value;
}

uint16_t hdc2080_readID(void)
{
	return hdc2080_readRegs(DEVICE_ID_L);
//	uint16_t device_id = 0x00;
//	device_id = hdc2080_readReg(DEVICE_ID_H);
//	device_id = (device_id << 8) | (hdc2080_readReg(DEVICE_ID_L));
//	return device_id;
}

uint16_t hdc2080_readTemp(void)
{
	return hdc2080_readRegs(TEMP_LOW);
//	uint16_t temp;
//	temp = hdc2080_readReg(TEMP_HIGH);
//	temp = (temp << 8) | (hdc2080_readReg(TEMP_LOW));
//	return temp; // temp = temp * 165 / 65536 - 40;
}

uint16_t hdc2080_readHumidity(void)
{
	return hdc2080_readRegs(HUMID_LOW);
//	uint16_t humidity;
//	humidity = hdc2080_readReg(HUMID_HIGH);
//	humidity = (humidity << 8) | (hdc2080_readReg(HUMID_LOW));
//	return humidity; //humidity = humidity/65536 * 100;
}

void hdc2080_enableHeater(void)
{
	uint8_t configContents;	//Stores current contents of config register

	configContents = hdc2080_readReg(CONFIG);

	//set bit 3 to 1 to enable heater
	configContents = (configContents | 0x08);

	hdc2080_writeReg(CONFIG, configContents);

}

void hdc2080_disableHeater(void)
{
	uint8_t configContents;	//Stores current contents of config register

	configContents = hdc2080_readReg(CONFIG);

	//set bit 3 to 0 to disable heater (all other bits 1)
	configContents = (configContents & 0xF7);
	hdc2080_writeReg(CONFIG, configContents);

}



void hdc2080_setLowTemp(uint32_t temp)
{
	uint8_t temp_thresh_low;

	// Verify user is not trying to set value outside bounds
	if (temp < -40)
	{
		temp = -40;
	}
	else if (temp > 125)
	{
		temp = 125;
	}

	// Calculate value to load into register
	temp_thresh_low = (uint8_t)(256 * (temp + 40)/165);

	hdc2080_writeReg(TEMP_THR_L, temp_thresh_low);

}

void hdc2080_setHighTemp(uint32_t temp)
{
	uint8_t temp_thresh_high;

	// Verify user is not trying to set value outside bounds
	if (temp < -40)
	{
		temp = -40;
	}
	else if (temp > 125)
	{
		temp = 125;
	}

	// Calculate value to load into register
	temp_thresh_high = (uint8_t)(256 * (temp + 40)/165);

	hdc2080_writeReg(TEMP_THR_H, temp_thresh_high);

}

void hdc2080_setHighHumidity(uint32_t humid)
{
	uint8_t humid_thresh;

	// Verify user is not trying to set value outside bounds
	if (humid < 0)
	{
		humid = 0;
	}
	else if (humid > 100)
	{
		humid = 100;
	}

	// Calculate value to load into register
	humid_thresh = (uint8_t)(256 * (humid)/100);

	hdc2080_writeReg(HUMID_THR_H, humid_thresh);

}

void hdc2080_setLowHumidity(uint32_t humid)
{
	uint8_t humid_thresh;

	// Verify user is not trying to set value outside bounds
	if (humid < 0)
	{
		humid = 0;
	}
	else if (humid > 100)
	{
		humid = 100;
	}

	// Calculate value to load into register
	humid_thresh = (uint8_t)(256 * (humid)/100);

	hdc2080_writeReg(HUMID_THR_L, humid_thresh);

}

//  Return humidity from the threshold registers
uint16_t hdc2080_readHumidityThreshold(void)
{
	return hdc2080_readRegs(HUMID_THR_L);
}

//  Return temperature from the low threshold register
uint16_t hdc2080_readTempThreshold(void)
{
	return hdc2080_readRegs(TEMP_THR_L);
}


/* Upper two bits of the MEASUREMENT_CONFIG register controls
   the temperature resolution*/
void hdc2080_setTempRes(uint8_t resolution)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(MEASUREMENT_CONFIG);

	switch(resolution)
	{
		case FOURTEEN_BIT:
			configContents = (configContents & 0x3F);
			break;

		case ELEVEN_BIT:
			configContents = (configContents & 0x7F);
			configContents = (configContents | 0x40);
			break;

		case NINE_BIT:
			configContents = (configContents & 0xBF);
			configContents = (configContents | 0x80);
			break;

		default:
			configContents = (configContents & 0x3F);
	}

	hdc2080_writeReg(MEASUREMENT_CONFIG, configContents);

}
/*  Bits 5 and 6 of the MEASUREMENT_CONFIG register controls
    the humidity resolution*/
void hdc2080_setHumidRes(uint8_t resolution)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(MEASUREMENT_CONFIG);

	switch(resolution)
	{
		case FOURTEEN_BIT:
			configContents = (configContents & 0xCF);
			break;

		case ELEVEN_BIT:
			configContents = (configContents & 0xDF);
			configContents = (configContents | 0x10);
			break;

		case NINE_BIT:
			configContents = (configContents & 0xEF);
			configContents = (configContents | 0x20);
			break;

		default:
			configContents = (configContents & 0xCF);
	}

	hdc2080_writeReg(MEASUREMENT_CONFIG, configContents);
}

/*  Bits 2 and 1 of the MEASUREMENT_CONFIG register controls
    the measurement mode  */
void hdc2080_setMeasurementMode(uint8_t mode)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(MEASUREMENT_CONFIG);

	switch(mode)
	{
		case TEMP_AND_HUMID:
			configContents = (configContents & 0xF9);
			break;

		case TEMP_ONLY:
			configContents = (configContents & 0xFC);
			configContents = (configContents | 0x02);
			break;

		case HUMID_ONLY:
			configContents = (configContents & 0xFD);
			configContents = (configContents | 0x04);
			break;

		default:
			configContents = (configContents & 0xF9);
	}

	hdc2080_writeReg(MEASUREMENT_CONFIG, configContents);
}

/*  Bit 0 of the MEASUREMENT_CONFIG register can be used
    to trigger measurements  */
void hdc2080_triggerMeasurement(void)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(MEASUREMENT_CONFIG);

	configContents = (configContents | 0x01);
	hdc2080_writeReg(MEASUREMENT_CONFIG, configContents);
}

/*  Bit 7 of the CONFIG register can be used to trigger a
    soft reset  */
void hdc2080_reset(void)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(CONFIG);

	configContents = (configContents | 0x80);
	hdc2080_writeReg(CONFIG, configContents);
	HAL_Delay(50);
}

/*  Bit 2 of the CONFIG register can be used to enable/disable
    the interrupt pin  */
void hdc2080_enableInterrupt(void)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(CONFIG);

	configContents = (configContents | 0x04);
	hdc2080_writeReg(CONFIG, configContents);
}

/*  Bit 2 of the CONFIG register can be used to enable/disable
    the interrupt pin  */
void hdc2080_disableInterrupt(void)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(CONFIG);

	configContents = (configContents & 0xFB);
	hdc2080_writeReg(CONFIG, configContents);
}


/*  Bits 6-4  of the CONFIG register controls the measurement
    rate  */
void hdc2080_setRate(uint8_t rate)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(CONFIG);

	switch(rate)
	{
		case MANUAL:
			configContents = (configContents & 0x8F);
			break;

		case TWO_MINS:
			configContents = (configContents & 0x9F);
			configContents = (configContents | 0x10);
			break;

		case ONE_MINS:
			configContents = (configContents & 0xAF);
			configContents = (configContents | 0x20);
			break;

		case TEN_SECONDS:
			configContents = (configContents & 0xBF);
			configContents = (configContents | 0x30);
			break;

		case FIVE_SECONDS:
			configContents = (configContents & 0xCF);
			configContents = (configContents | 0x40);
			break;

		case ONE_HZ:
			configContents = (configContents & 0xDF);
			configContents = (configContents | 0x50);
			break;

		case TWO_HZ:
			configContents = (configContents & 0xEF);
			configContents = (configContents | 0x60);
			break;

		case FIVE_HZ:
			configContents = (configContents | 0x70);
			break;

		default:
			configContents = (configContents & 0x8F);
	}

	hdc2080_writeReg(CONFIG, configContents);
}

/*  Bit 1 of the CONFIG register can be used to control the
    the interrupt pins polarity */
void hdc2080_setInterruptPolarity(uint8_t polarity)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(CONFIG);

	switch(polarity)
	{
		case ACTIVE_LOW:
			configContents = (configContents & 0xFD);
			break;

		case ACTIVE_HIGH:
			configContents = (configContents | 0x02);
			break;

		default:
			configContents = (configContents & 0xFD);
	}

	hdc2080_writeReg(CONFIG, configContents);
}

/*  Bit 0 of the CONFIG register can be used to control the
    the interrupt pin's mode */
void hdc2080_setInterruptMode(uint8_t mode)
{
	uint8_t configContents;
	configContents = hdc2080_readReg(CONFIG);

	switch(mode)
	{
		case LEVEL_MODE:
			configContents = (configContents & 0xFE);
			break;

		case COMPARATOR_MODE:
			configContents = (configContents | 0x01);
			break;

		default:
			configContents = (configContents & 0xFE);
	}

	hdc2080_writeReg(CONFIG, configContents);
}


uint8_t hdc2080_readInterruptStatus(void)
{
	uint8_t regContents;
	regContents = hdc2080_readReg(INTERRUPT_DRDY);
	return regContents;

}

//  Clears the maximum temperature register
void hdc2080_clearMaxTemp(void)
{
	hdc2080_writeReg(TEMP_MAX, 0x00);
}

//  Clears the maximum humidity register
void hdc2080_clearMaxHumidity(void)
{
	hdc2080_writeReg(HUMID_MAX, 0x00);
}

//  Reads the maximum temperature register
uint8_t hdc2080_readMaxTemp(void)
{
	return hdc2080_readReg(TEMP_MAX);
}

//  Reads the maximum humidity register
uint8_t hdc2080_readMaxHumidity(void)
{
	return hdc2080_readReg(HUMID_MAX);
}


// Enables the interrupt pin for comfort zone operation
void hdc2080_enableThresholdInterrupt(void)
{

	uint8_t regContents;
	regContents = hdc2080_readReg(INTERRUPT_CONFIG);

	regContents = (regContents | 0x78);

	hdc2080_writeReg(INTERRUPT_CONFIG, regContents);
}

// Disables the interrupt pin for comfort zone operation
void hdc2080_disableThresholdInterrupt(void)
{
	uint8_t regContents;
	regContents = hdc2080_readReg(INTERRUPT_CONFIG);

	regContents = (regContents & 0x87);

	hdc2080_writeReg(INTERRUPT_CONFIG, regContents);
}

// enables the interrupt pin for DRDY operation
void hdc2080_enableDRDYInterrupt(void)
{
	uint8_t regContents;
	regContents = hdc2080_readReg(INTERRUPT_CONFIG);

	regContents = (regContents | 0x80);

	hdc2080_writeReg(INTERRUPT_CONFIG, regContents);
}

// disables the interrupt pin for DRDY operation
void hdc2080_disableDRDYInterrupt(void)
{
	uint8_t regContents;
	regContents = hdc2080_readReg(INTERRUPT_CONFIG);

	regContents = (regContents & 0x7F);

	hdc2080_writeReg(INTERRUPT_CONFIG, regContents);
}
