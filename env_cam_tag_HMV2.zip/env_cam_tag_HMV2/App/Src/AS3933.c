/*
 * AS3933.c
 *
 *  Created on: Feb 22, 2019
 *      Author: katanbaf
 */

#include "AS3933.h"


extern uint8_t WAKEUUP_PATTERN_1st_BYTE;
extern uint8_t WAKEUUP_PATTERN_2nd_BYTE;
extern SPI_HandleTypeDef hspi2;

#define CS_GPIO_PORT RX_CS_GPIO_Port
#define CS_GPIO_PIN RX_CS_Pin
#define hspi (&hspi2)

uint8_t as3933_cmd(cmd_type cmd, uint8_t reg_index, uint8_t cmd_data)
{
	uint8_t cmd_array[2];
	uint8_t res_array[2];

	//Assert chip Select
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, SET);

    //Send first Byte
	cmd_array[0] = ((uint8_t)cmd & 0x3) << 6 | (reg_index & 0x3f);
	cmd_array[1] = cmd_data;

    while(HAL_SPI_GetState(hspi) != HAL_SPI_STATE_READY);
    HAL_SPI_TransmitReceive_DMA(hspi, &cmd_array[0], &res_array[0], 2);

    //Send second Byte
//    while(HAL_SPI_GetState(hspi) != HAL_SPI_STATE_READY);
//    HAL_SPI_TransmitReceive_DMA(hspi, &cmd_data, &resp, 1);

    //Release chip select
    while(HAL_SPI_GetState(hspi) != HAL_SPI_STATE_READY);
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, RESET);


    return res_array[1];
}

void as3933_direct_cmd(direct_cmd_type dir_cmd_data)
{
    uint8_t cmd, resp;
	//Assert chip Select
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, SET);

    //Send first Byte
    cmd = ((uint8_t)cmd_direct & 0x3) << 6 | ((uint8_t)dir_cmd_data & 0x3f);
    while(HAL_SPI_GetState(hspi) != HAL_SPI_STATE_READY);
    HAL_SPI_TransmitReceive_DMA(hspi, &cmd, &resp, 1);

    //Release chip select
    while(HAL_SPI_GetState(hspi) != HAL_SPI_STATE_READY);
	HAL_GPIO_WritePin(CS_GPIO_PORT, CS_GPIO_PIN, RESET);

    return;
}

void init_as3933(){
    as3933_cmd(cmd_write, 0, pattern_16bit | data_mask_en | on_off_dis | scan_mode_dis | ch1_en);
    as3933_cmd(cmd_write, 1, data_slicer_dis | agc_burst_only_dis | agc_both_dir_en | antenna_damper_dis | manchester_decoder_en | double_pattern_cor_dis | correlator_en | crystal_osc_en);
    as3933_cmd(cmd_write, 2, data_slicer_threshold_red_dis | external_clocK_gen_dis | amplifier_gain_boost_en | display_clk_dis | freq_det_tol_tight );
    as3933_cmd(cmd_write, 3, comp_hystersis_20mv | hystersis_pos_edge_only | data_slicer_time_cons_800us | env_det_time_cons_SR4096);
    as3933_cmd(cmd_write, 4, off_time_1ms | ant_damp_res_27k | gain_reduction_0dB);
    as3933_cmd(cmd_write, 5, WAKEUUP_PATTERN_2nd_BYTE);
    as3933_cmd(cmd_write, 6, WAKEUUP_PATTERN_1st_BYTE);
    as3933_cmd(cmd_write, 7, TO_350ms | SR_4096);
    as3933_cmd(cmd_write, 8, AW_NONE);
    as3933_cmd(cmd_write, 9, agc_en);
    as3933_cmd(cmd_write, 16, clk_gen_dis);
    as3933_cmd(cmd_write, 17, 0x01);
    as3933_cmd(cmd_write, 18, cap_bank_ch2_0pf);
    as3933_cmd(cmd_write, 19, cap_bank_ch3_0pf);
}

#define wake_timeout 100
uint8_t as3933_wakeCallback()
{
	uint8_t rssi;
	uint8_t rx_data = 0;
    uint8_t pre_bit = 0;
    uint8_t new_bit;
    uint8_t num_received_bits = 0;
    uint16_t count;

    count = 0;
    while((num_received_bits < 8) && (count < wake_timeout))
    {
        new_bit = HAL_GPIO_ReadPin(RX_CL_DT_GPIO_Port, RX_CL_DT_Pin);
        if ((pre_bit == 0) && (new_bit != 0))
        {
            rx_data = (rx_data << 1) | ((HAL_GPIO_ReadPin(RX_DATA_GPIO_Port, RX_DATA_Pin))!= 0);
            num_received_bits ++;
        }
        pre_bit = new_bit;
        count++;
    }
//	HAL_GPIO_TogglePin(LEDR_GPIO_Port, LEDR_Pin);
	rssi = as3933_cmd(cmd_read, 11, 0);
	as3933_direct_cmd(clear_wake);
	return rx_data;

}
