/*
 * test_func.c
 *
 *  Created on: Jan 24, 2020
 *      Author: katanbaf
 */


#include "aux_func.h"
#include "AS3933.h"
#include "HDC2080.h"

extern uint8_t pkt_complete;
extern uint8_t uart_end[4];

uint8_t as3933_test()
{
	uint8_t rssi;
	uint8_t rx_data = 0;
    uint8_t pre_bit = 0;
    uint8_t new_bit;
    uint8_t num_received_bits = 0;
    uint16_t count;

	while(!HAL_GPIO_ReadPin(RX_WAKE_GPIO_Port, RX_WAKE_Pin));
    count = 0;
    while((num_received_bits < 8) && (count < 100))
    {
        new_bit = HAL_GPIO_ReadPin(RX_CL_DT_GPIO_Port, RX_CL_DT_Pin);
        if ((pre_bit == 0) && (new_bit != 0))
        {
            rx_data = (rx_data << 1) | ((HAL_GPIO_ReadPin(RX_DATA_GPIO_Port, RX_DATA_Pin))!= 0);
            num_received_bits ++;
        }
        pre_bit = new_bit;
        count++;
    }
//	HAL_GPIO_TogglePin(LEDR_GPIO_Port, LEDR_Pin);
	rssi = as3933_cmd(cmd_read, 11, 0);
	as3933_direct_cmd(clear_wake);
	return rx_data;

}

void bs_send(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len)
{
	uint16_t crc;
	crc = HAL_CRC_Calculate(&hcrc, (uint32_t*)&payload[0], payload_len);

	transmitBuffer[size-2]  = crc >> 8;
	transmitBuffer[size-1]  = crc & 0xff;

	HAL_SPI_Transmit_DMA(&hspi2, &transmitBuffer[0], size);
//	HAL_Delay(2);
}

void uart_send(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len)
{
	transmitBuffer[size-2]  = 10;
	transmitBuffer[size-1]  = 13;

//	HAL_UART_Transmit(&hlpuart1, &transmitBuffer[0], size,5);
//	HAL_Delay(2);
}

void HDC2080_test(uint16_t * temp, uint16_t* humidity)
{
	hdc2080_triggerMeasurement();
    *temp = hdc2080_readTemp();
	*humidity = hdc2080_readHumidity();
}

void uplink_repeat(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len, uint8_t repeat)
{
	uint8_t i = 0;
	do
	{
		if(pkt_complete ==1)
		{
#ifdef BS
			bs_send(transmitBuffer, size, payload, payload_len);
			pkt_complete = 0;
		}
		HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);

#else
		}
		uart_send(transmitBuffer, size, payload, payload_len);
#endif
		i++;

	}

	while(i < repeat);
}

void uplink(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len)
{
#ifdef BS
	if(pkt_complete ==1)
	{
		bs_send(transmitBuffer, size, payload, payload_len);
		pkt_complete = 0;
	}
	HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);
#else
	uart_send(transmitBuffer, size, payload, payload_len);
#endif
}
