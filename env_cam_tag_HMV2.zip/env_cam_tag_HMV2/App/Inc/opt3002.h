/*
 * opt3002.h
 *
 *  Created on: Jan 24, 2020
 *      Author: katanbaf
 */

#ifndef INC_OPT3002_H_
#define INC_OPT3002_H_


#include "main.h"

uint16_t opt3002_readManufacturerID();
uint16_t opt3002_readResultOnce();
uint16_t opt3002_readReg();
void opt3002_writeReg(uint8_t reg, uint16_t data);
void opt3002_continous();
void opt3002_read(uint8_t* data);


#endif /* INC_OPT3002_H_ */
