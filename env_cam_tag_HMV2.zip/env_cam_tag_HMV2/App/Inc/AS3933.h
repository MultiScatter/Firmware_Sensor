/*
 * AS3933.h
 *
 *  Created on: Feb 22, 2019
 *      Author: Mohamad katanbaf
 */

#ifndef AS3933_H_
#define AS3933_H_

#include "main.h"

typedef enum
{
    cmd_write,
    cmd_read,
    reserved,
    cmd_direct
}cmd_type;

typedef enum
{
    clear_wake,
    reset_RSSI,
    trim_osc,
    clear_false,
    preset_default,
    calib_RCO_LC
}direct_cmd_type;

//reg0
#define pattern_16bit 0
#define pattern_32bit 0x80
#define data_mask_dis 0
#define data_mask_en 0x40
#define on_off_dis 0
#define on_off_en 0x20
#define scan_mode_dis 0
#define scan_mode_en 0x10
#define ch2_dis 0
#define ch2_en 0x08
#define ch3_dis 0
#define ch3_en 0x04
#define ch1_dis 0
#define ch1_en 0x02
#define ch_all_dis 0
#define ch_all_en 0x0e

//reg1
#define data_slicer_dis 0
#define data_slicer_en 0x80
#define agc_burst_only_dis 0
#define agc_burst_only_en 0x40
#define agc_both_dir_dis 0
#define agc_both_dir_en 0x20
#define antenna_damper_dis 0
#define antenna_damper_en 0x10
#define manchester_decoder_dis 0
#define manchester_decoder_en 0x08
#define double_pattern_cor_dis 0
#define double_pattern_cor_en 0x04
#define correlator_dis 0
#define correlator_en 0x02
#define crystal_osc_dis 0
#define crystal_osc_en 0x01

//reg2
#define data_slicer_threshold_red_dis 0
#define data_slicer_threshold_red_en 0x80
#define external_clocK_gen_dis 0
#define external_clocK_gen_en 0x40
#define amplifier_gain_boost_dis 0
#define amplifier_gain_boost_en 0x20
#define display_clk_dis 0
#define display_clk_en 0xc0
#define freq_det_tol_relaxed 0x00
#define freq_det_tol_medium 0x01
#define freq_det_tol_tight 0x10

//reg3
#define comp_hystersis_40mv 0
#define comp_hystersis_20mv 0x80
#define hystersis_pos_edge_only 0
#define hystersis_both_edge 0x40
#define data_slicer_time_cons_800us  0x00
#define data_slicer_time_cons_1150us 0x08
#define data_slicer_time_cons_1550us 0x10
#define data_slicer_time_cons_1900us 0x18
#define data_slicer_time_cons_2300us 0x20
#define data_slicer_time_cons_2650us 0x28
#define data_slicer_time_cons_3000us 0x30
#define data_slicer_time_cons_3500us 0x38
#define env_det_time_cons_SR4096 0x00
#define env_det_time_cons_SR2184 0x01
#define env_det_time_cons_SR1490 0x02
#define env_det_time_cons_SR1130 0x03
#define env_det_time_cons_SR910 0x04
#define env_det_time_cons_SR762 0x05
#define env_det_time_cons_SR655 0x06
#define env_det_time_cons_SR512 0x07

//reg4
#define off_time_1ms 0x00
#define off_time_2ms 0x40
#define off_time_4ms 0x80
#define off_time_8ms 0xc0
#define ant_damp_res_1k 0x00
#define ant_damp_res_3k 0x10
#define ant_damp_res_9k 0x20
#define ant_damp_res_27k 0x30
#define gain_reduction_0dB 0x00
#define gain_reduction_4dB 0x04
#define gain_reduction_8dB 0x06
#define gain_reduction_12dB 0x08
#define gain_reduction_16dB 0x0a
#define gain_reduction_20dB 0x0c
#define gain_reduction_24dB 0x0e

//reg7
#define    TO_0ms   0x00
#define    TO_50ms  0x20
#define    TO_100ms 0x40
#define    TO_150ms 0x60
#define    TO_200ms 0x80
#define    TO_250ms 0xa0
#define    TO_300ms 0xc0
#define    TO_350ms 0xe0
#define    SR_RESERVED0 0x00
#define    SR_RESERVED1 0x01
#define    SR_RESERVED2 0x02
#define    SR_4096  0x03
#define    SR_3276  0x04
#define    SR_2730  0x05
#define    SR_2340  0x06
#define    SR_2048  0x07
#define    SR_1820  0x08
#define    SR_1638  0x09
#define    SR_1489  0x0a
#define    SR_1365  0x0b
#define    SR_1260  0x0c
#define    SR_1170  0x0d
#define    SR_1092  0x0e
#define    SR_1024  0x0f
#define    SR_963   0x10
#define    SR_910   0x11
#define    SR_862   0x12
#define    SR_819   0x13
#define    SR_780   0x14
#define    SR_744   0x15
#define    SR_712   0x16
#define    SR_682   0x17
#define    SR_655   0x18
#define    SR_630   0x19
#define    SR_606   0x1a
#define    SR_585   0x1b
#define    SR_564   0x1c
#define    SR_546   0x1d
#define    SR_528   0x1e
#define    SR_512   0x1f

//reg8
#define    AW_NONE  0x00
#define    AW_1sec  0x01
#define    AW_5sec  0x02
#define    AW_20sec 0x03
#define    AW_2min  0x04
#define    AW_15min 0x05
#define    AW_1hour 0x06
#define    AW_2hour 0x07

//reg9
#define agc_en 0
#define agc_dis  0x80

//reg16
#define clk_gen_dis 0
#define clk_gen_en 0x80
#define set_rc_osc_to_min_freq 0x20
#define set_rc_osc_to_max_freq 0x10
#define disp_ch3_on_data_pin 0x04
#define disp_ch2_on_data_pin 0x02
#define disp_ch1_on_data_pin 0x01

//reg17
#define cap_bank_ch1_0pf    0x00

//reg18
#define cap_bank_ch2_0pf    0x00

//reg19
#define cap_bank_ch3_0pf    0x00

uint8_t as3933_cmd(cmd_type cmd, uint8_t reg_index, uint8_t cmd_data);
void as3933_direct_cmd(direct_cmd_type dir_cmd_data);
void init_as3933();
uint8_t as3933_wakeCallback();

#endif /* AS3933_H_ */
