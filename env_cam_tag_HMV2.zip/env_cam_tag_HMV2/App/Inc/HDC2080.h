/*
 * HDC2080.h
 *
 *  Created on: Jan 24, 2020
 *      Author: katanbaf
 */

#ifndef INC_HDC2080_H_
#define INC_HDC2080_H_

#include "main.h"

//Define Register Map
#define TEMP_LOW 0x00
#define TEMP_HIGH 0x01
#define HUMID_LOW 0x02
#define HUMID_HIGH 0x03
#define INTERRUPT_DRDY 0x04
#define TEMP_MAX 0x05
#define HUMID_MAX 0x06
#define INTERRUPT_CONFIG 0x07
#define TEMP_OFFSET_ADJUST 0x08
#define HUM_OFFSET_ADJUST 0x09
#define TEMP_THR_L 0x0A
#define TEMP_THR_H 0x0B
#define HUMID_THR_L 0x0C
#define HUMID_THR_H 0x0D
#define CONFIG 0x0E
#define MEASUREMENT_CONFIG 0x0F
#define MID_L 0xFC
#define MID_H 0xFD
#define DEVICE_ID_L 0xFE
#define DEVICE_ID_H 0xFF

//  Constants for setting measurement resolution
#define FOURTEEN_BIT 0
#define ELEVEN_BIT 1
#define NINE_BIT  2

//  Constants for setting sensor mode
#define TEMP_AND_HUMID 0
#define TEMP_ONLY	   1
#define HUMID_ONLY	   2
#define ACTIVE_LOW	   0
#define ACTIVE_HIGH	   1
#define LEVEL_MODE		0
#define COMPARATOR_MODE 1

//  Constants for setting sample rate
#define MANUAL			0
#define TWO_MINS		1
#define ONE_MINS		2
#define TEN_SECONDS		3
#define	FIVE_SECONDS	4
#define ONE_HZ			5
#define TWO_HZ			6
#define FIVE_HZ			7

uint16_t hdc2080_readID(void);					// Returns the device ID
void hdc2080_init(void);						// Initialization commands
void hdc2080_readSensors(uint8_t* data);		// Read temperature and humidity sensors in one I2c read
uint16_t hdc2080_readTemp(void);				// Returns the temperature in degrees C
uint16_t hdc2080_readHumidity(void);			// Returns the relative humidity
void hdc2080_enableHeater(void);				// Enables the heating element
void hdc2080_disableHeater(void);				// Disables the heating element
void hdc2080_setLowTemp(uint32_t temp);			// Sets low threshold temperature (in c)
void hdc2080_setHighTemp(uint32_t temp);		// Sets high threshold temperature (in c)
void hdc2080_setHighHumidity(uint32_t humid);	// Sets high Humiditiy threshold
void hdc2080_setLowHumidity(uint32_t humid);	// Sets low Humidity threshold
uint16_t hdc2080_readHumidityThreshold(void);	// Returns contents of low humidity threshold register
uint16_t hdc2080_readTempThreshold(void);		// Returns contents of low temperature threshold register (in C)
void hdc2080_triggerMeasurement(void);			// Triggers a manual temperature/humidity reading
void hdc2080_reset(void); 						// Triggers a software reset
void hdc2080_enableInterrupt(void);				// Enables the interrupt/DRDY pin
void hdc2080_disableInterrupt(void); 			// Disables the interrupt/DRDY pin (High Z)
uint8_t hdc2080_readInterruptStatus(void); 		// Reads the status of the interrupt register
void hdc2080_clearMaxTemp(void);				// Clears the Maximum temperature register
void hdc2080_clearMaxHumidity(void);			// Clears the Maximum humidity register
uint8_t hdc2080_readMaxTemp(void); 				// Reads the maximum temperature register
uint8_t hdc2080_readMaxHumidity(void);			// Reads the maximum humidity register
void hdc2080_enableThresholdInterrupt(void);	// Enables high and low temperature/humidity interrupts
void hdc2080_disableThresholdInterrupt(void);	// Disables high and low temperature/humidity interrupts
void hdc2080_enableDRDYInterrupt(void);			// Enables data ready interrupt
void hdc2080_disableDRDYInterrupt(void);		// Disables data ready interrupt



/* Sets Temperature & Humidity Resolution, 3 options
   0 - 14 bit
   1 - 11 bit
   2 - 9 bit
   default - 14 bit							*/
void hdc2080_setTempRes(uint8_t resolution);
void hdc2080_setHumidRes(uint8_t resolution);

/* Sets measurement mode, 3 options
   0 - Temperature and Humidity
   1 - Temperature only
   2 - Humidity only
   default - Temperature & Humidity			*/
void hdc2080_setMeasurementMode(uint8_t mode);

/* Sets reading rate, 8 options
   0 - Manual
   1 - reading every 2 minutes
   2 - reading every minute
   3 - reading every ten seconds
   4 - reading every 5 seconds
   5 - reading every second
   6 - reading at 2Hz
   7 - reading at 5Hz
   default - Manual		*/
void hdc2080_setRate(uint8_t rate);

/* Sets Interrupt polarity, 2 options
   0 - Active Low
   1 - Active High
   default - Active Low			*/
void hdc2080_setInterruptPolarity(uint8_t polarity);

/* Sets Interrupt mode, 2 options
   0 - Level sensitive
   1 - Comparator mode
   default - Level sensitive	*/
void hdc2080_setInterruptMode(uint8_t polarity);



#endif /* INC_HDC2080_H_ */
