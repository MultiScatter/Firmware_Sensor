/*
 * test_func.h
 *
 *  Created on: Jan 24, 2020
 *      Author: katanbaf
 */

#ifndef INC_TEST_FUNC_H_
#define INC_TEST_FUNC_H_

#include "main.h"

#define BS


extern CRC_HandleTypeDef hcrc;

extern I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c2;

//extern UART_HandleTypeDef hlpuart1;

extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern DMA_HandleTypeDef hdma_spi2_tx;
extern DMA_HandleTypeDef hdma_spi2_rx;

uint8_t as3933_test();
void HDC2080_test(uint16_t * temp, uint16_t* humidity);
void bs_send(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len);
void uart_send(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len);
void uplink_repeat(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len, uint8_t repeat);
void uplink(uint8_t* transmitBuffer, uint8_t size, uint8_t* payload, uint8_t payload_len);

#endif /* INC_TEST_FUNC_H_ */
